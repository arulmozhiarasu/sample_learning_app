import frappe

def welcome_student(doc, method):
    """Simple welcome message"""
    frappe.msgprint(f"Welcome {doc.student_name}!")
