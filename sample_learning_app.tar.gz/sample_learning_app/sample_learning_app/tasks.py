import frappe
from frappe.utils import now_datetime

def student_report():
    try:
        total_students = frappe.db.count('Student')
        total_courses = frappe.db.count('Course')
        current_time = now_datetime()
        
        # Create visible entry in Error Log
        frappe.log_error(
            f"Report at {current_time}:\n" +
            f"Total Students: {total_students}\n" +
            f"Total Courses: {total_courses}\n" +
            f"Scheduler is working perfectly!",
            "Scheduled Task Success"
        )
        
        print(f"Scheduler task completed: {total_students} students, {total_courses} courses")
        
    except Exception as e:
        frappe.log_error(f"Scheduler task failed: {str(e)}", "Scheduler Error")
