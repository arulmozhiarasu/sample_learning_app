import frappe
from frappe.model.document import Document

class Student(Document):
    def validate(self):
        """Simple validation"""
        if self.email and '@' not in self.email:
            frappe.throw("Please enter a valid email address")
    
    def after_insert(self):
        """Simple welcome message"""
        frappe.msgprint(f"Welcome {self.student_name}!")

@frappe.whitelist()
def get_student_count():
    """Simple method to count students"""
    return frappe.db.count('Student')
