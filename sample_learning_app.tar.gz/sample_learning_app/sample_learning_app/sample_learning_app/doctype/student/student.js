frappe.ui.form.on('Student', {
    refresh: function(frm) {
        // Single custom button
        if (frm.doc.name) {
            frm.add_custom_button(__('Send Welcome Email'), function() {
                frappe.msgprint(`Welcome email sent to ${frm.doc.student_name}!`);
            });
        }
    },
    
    // Auto-format student name
    student_name: function(frm) {
        if (frm.doc.student_name) {
            frm.set_value('student_name', frm.doc.student_name.toUpperCase());
        }
    }
});
