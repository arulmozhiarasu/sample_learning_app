frappe.ui.form.on('Instructor', {
    refresh: function(frm) {
        // Single custom button
        if (frm.doc.name) {
            frm.add_custom_button(__('Send Welcome Email'), function() {
                frappe.msgprint(`Welcome email sent to ${frm.doc.instructor_name}!`);
            });
        }
    }
});
