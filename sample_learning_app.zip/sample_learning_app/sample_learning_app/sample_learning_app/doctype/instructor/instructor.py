import frappe
from frappe.model.document import Document

class Instructor(Document):
    def validate(self):
        """Simple validation"""
        if self.email and '@' not in self.email:
            frappe.throw("Please enter a valid email address")
    
    def after_insert(self):
        """Simple welcome message"""
        frappe.msgprint(f"Welcome Instructor {self.instructor_name}!")
